package com.pushtorefresh.storio3.common.annotations.processor

class SkipNotAnnotatedClassWithAnnotatedParentException(message: String) : Exception(message)