package com.pushtorefresh.storio3.sqlite.queries;

public interface GetQuery {
}
