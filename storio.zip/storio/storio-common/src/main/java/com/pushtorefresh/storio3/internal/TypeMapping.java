package com.pushtorefresh.storio3.internal;

/**
 * Common interface for Type Mapping.
 *
 * @param <Type> type to map.
 */
public interface TypeMapping<Type> {
}
