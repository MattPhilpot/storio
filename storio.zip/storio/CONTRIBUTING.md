`Hello, dear developer`
We will be happy to see your Pull Request!

Actually, we don't want to limit you, so just write clean & good code with tests and everything will be okay :smile:

But, please first file an issue with feature request or bug report or contact us in existent one before contributing.

Also: GitHub issues are for feature requests and bug reports only, please ask usages question on StackOverflow.

#### Building project:

To build and test the project you need to execute:
```bash
# from root project directory
sh ci.sh
```
