package com.pushtorefresh.storio3.contentresolver.annotations;

import com.pushtorefresh.storio3.contentresolver.ContentResolverTypeMapping;

/**
 * Generated mapping with collection of resolvers
 */
public class PrimitivePrivateFieldsContentResolverTypeMapping extends ContentResolverTypeMapping<PrimitivePrivateFields> {
    public PrimitivePrivateFieldsContentResolverTypeMapping() {
        super(new PrimitivePrivateFieldsStorIOContentResolverPutResolver(),
                new PrimitivePrivateFieldsStorIOContentResolverGetResolver(),
                new PrimitivePrivateFieldsStorIOContentResolverDeleteResolver());
    }
}
