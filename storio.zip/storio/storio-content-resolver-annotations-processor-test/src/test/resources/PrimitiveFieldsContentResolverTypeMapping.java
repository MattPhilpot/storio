package com.pushtorefresh.storio3.contentresolver.annotations;

import com.pushtorefresh.storio3.contentresolver.ContentResolverTypeMapping;

/**
 * Generated mapping with collection of resolvers.
 */
public class PrimitiveFieldsContentResolverTypeMapping extends ContentResolverTypeMapping<PrimitiveFields> {
    public PrimitiveFieldsContentResolverTypeMapping() {
        super(new PrimitiveFieldsStorIOContentResolverPutResolver(),
                new PrimitiveFieldsStorIOContentResolverGetResolver(),
                new PrimitiveFieldsStorIOContentResolverDeleteResolver());
    }
}