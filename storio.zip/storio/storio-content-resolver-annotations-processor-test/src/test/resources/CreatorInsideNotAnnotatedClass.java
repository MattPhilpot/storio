package com.pushtorefresh.storio3.contentresolver.annotations;

public class CreatorInsideNotAnnotatedClass {

    @StorIOContentResolverCreator
    CreatorInsideNotAnnotatedClass() {

    }
}