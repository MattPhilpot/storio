package com.pushtorefresh.storio3.contentresolver.annotations;

public interface CreatorNotInsideClass {

    @StorIOContentResolverCreator
    CreatorNotInsideClass id();
}